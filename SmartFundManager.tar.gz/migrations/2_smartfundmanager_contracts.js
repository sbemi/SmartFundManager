var SmartFundManager = artifacts.require("./SmartFundManager.sol");

module.exports = function(deployer) {
  deployer.deploy(SmartFundManager);
};
