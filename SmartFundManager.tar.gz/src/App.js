import React, { Component } from 'react'
import SmartFundManager from './Components/SmartFundManager'

import './App.css'
import MultiThemeProvider from 'material-ui/styles/MuiThemeProvider';

class App extends Component {

  render() {
    return (
      <MultiThemeProvider>
      <div className="App">
      <header className="App-header">
      </header>
      <SmartFundManager />
      </div>
      </MultiThemeProvider>
    );
  }
}

export default App
